const movies = [
  { title: "A1ita", id: "16r0Y966jqJ3IVmpk4mLTiskSpJTw_abd" },
  { title: "Air Force 1", id: "14nvcmpWJXjwRu5Bqsn4EdcqAqlqiqk7R" },
  { title: "Carjacker", id: "1zRgz6mSvcJrA7DF2-40jnEhWx-Q9WWGA" },
  { title: "Cleaner", id: "1kFMFdCe7z_aIL_zjn0R1vWRefXOmUkuB" },
  { title: "Beekeeper", id: "1_D6ZX-U_Yu8_aOP-sWYycwnAtaUcjHCZ" },
  { title: "Inside Out", id: "1cpNoKwnn3TwhzEwSIC19_G8MKgKja2zD" },
  { title: "Bad Guy: The Bad Holiday", id: "1Grx7hhQNhJtL_FtCtLjIZRftVbHpGA2l" },
  { title: "The Bad Guys: Haunted Heist (2024)", id: "1njKg3rjT90UxEI6T1LHU5Q-UWOOvuigI" }
];

const container = document.getElementById("moviesContainer");

function renderMovies(list) {
  container.innerHTML = "";
  list.forEach(movie => {
    const downloadLink = `https://drive.google.com/uc?export=download&id=${movie.id}`;
    const card = document.createElement("div");
    card.classList.add("movie-card");
    card.innerHTML = `
      <h3>${movie.title}</h3>
      <a href="${downloadLink}" class="download-btn" target="_blank">Download Movie</a>
    `;
    container.appendChild(card);
  });
}

renderMovies(movies);

// Search filter
document.getElementById("searchInput").addEventListener("input", e => {
  const term = e.target.value.toLowerCase();
  const filtered = movies.filter(m => m.title.toLowerCase().includes(term));
  renderMovies(filtered);
});
